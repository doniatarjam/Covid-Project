// API key
const API_KEY = "pk.eyJ1IjoicG9zaDAwNyIsImEiOiJja3NsdHJvenkzMTF0Mm9vYW00MHhraG11In0.fxv5nw-tb2Jh6_8ceU6LEw"
