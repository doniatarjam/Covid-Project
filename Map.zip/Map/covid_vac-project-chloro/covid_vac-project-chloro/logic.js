// Creating our initial map object
// We set the longitude, latitude, and the starting zoom level
// This gets inserted into the div with an id of 'map'
const myMap = L.map("map", {
    center: [39.0458, -79.4938],
    zoom: 8
  });

const mapChloro = L.map("map-chloro", {
  center: [39.0458, -79.4938],
  zoom: 8
});

var geojson; 

// Adding a tile layer (the background map image) to our map
// We use the addTo method to add objects to our map
L.tileLayer("https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}", {
  attribution: "© <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> © <a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a> <strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
  tileSize: 512,
  maxZoom: 18,
  zoomOffset: -1,
  id: "mapbox/streets-v11",
  accessToken: API_KEY
}).addTo(myMap);

// Adding a tile layer (the background map image) to our map
// We use the addTo method to add objects to our map
L.tileLayer("https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}", {
  attribution: "© <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> © <a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a> <strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
  tileSize: 512,
  maxZoom: 18,
  zoomOffset: -1,
  id: "mapbox/streets-v11",
  accessToken: API_KEY
}).addTo(mapChloro);

// on each feature use feature data to create a pop-up
function onEachFeature(feature, layer) {

  if (feature.properties) {
      var popupContent;
      popupContent = feature.properties['fully_vaccinated'];
      console.log(popupContent);    
  }
  layer.bindPopup(popupContent);
}


fetch("templates/MD_vaccinations.geojson")
.then(function(response) {
    return response.json();
}).then(function(data) {
    var geojson_layer = L.geoJSON(data, {
      onEachFeature: function (feature, layer) {
        layer.bindPopup("<b>County name:</b> " + feature.properties.county + "<br>" +
        "<b> Fully vaccinated: " + feature.properties.fully_vaccinated + "</b><br>" +
        "<b> Population: " + feature.properties.population + "</b>")
    }});
    // add the geojson layer to the map
    geojson_layer.addTo(myMap);
});

function onEachFeatureCH(feature, layer) {
  layer.on({
      mouseover: highlightFeature,
      mouseout: resetHighlight,
      click: zoomToFeature
  });
}

fetch("templates/maryland_counties.geojson")
.then(function(response) {
    return response.json();
}).then(function(dataBoundary) {
 geojson = L.geoJSON(dataBoundary, {
    onEachFeature: onEachFeatureCH,
    style: style
  }).addTo(mapChloro);
  
  
});



function style(feature) {
  return {
      fillColor: getColor(feature.properties.fully_vaccinated),
      weight: 2,
      opacity: 1,
      color: 'white',
      dashArray: '2',
      fillOpacity: 0.8
  };
} 

function getColor(d) {
  console.log(d, 'd');
  return d > 10000000 ? '#800026' :
         d > 500000  ? '#BD0026' :
         d > 200000  ? '#E31A1C' :
         d > 100000  ? '#FC4E2A' :
         d > 50000   ? '#FD8D3C' :
         d > 20000   ? '#FEB24C' :
         d > 10000   ? '#FED976' :
                    '#FFEDA0';
}

function highlightFeature(e) {
  var layer = e.target;

  layer.setStyle({
      weight: 5,
      color: '#666',
      dashArray: '',
      fillOpacity: 0.7
  });

  if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
      layer.bringToFront();
  }
  info.update(layer.feature.properties);
}

function resetHighlight(e) {
  geojson.resetStyle(e.target);
  info.update();
}

function zoomToFeature(e) {
  mapChloro.fitBounds(e.target.getBounds());
}

var info = L.control();

info.onAdd = function (map) {
    this._div = L.DomUtil.create('div', 'info'); // create a div with a class "info"
    this.update();
    return this._div;
};

// method that we will use to update the control based on feature properties passed
info.update = function (props) {
  console.log(props, "props");
    this._div.innerHTML = '<h4>US County Full Vaccinated</h4>' +  (props ?
        '<b> County: ' + props.name + '</b><br /> ' + '<b> Full Vaccinated: ' + props.fully_vaccinated   
        : 'Hover over a county');
};

info.addTo(mapChloro);