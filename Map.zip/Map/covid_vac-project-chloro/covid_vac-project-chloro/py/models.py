from application import db
import pandas as pd
import numpy as np
import csv
import sqlalchemy
from sqlalchemy import create_engine, MetaData, PrimaryKeyConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Numeric, Text, Float


# Use SQLAlchemy to model table schema
Base = declarative_base()

class Ages(Base):
    __tablename__ = 'ages'
    age = Column(String, primary_key=True) 
    first_dose = Column(Integer)
    second_dose = Column(Integer)
    single_dose = Column(Integer)
	 
class Locations(Base):
    __tablename__ = 'loc'

    county = Column(Text, primary_key=True)
    county_fips = Column(Integer)
    latitude = Column(Numeric)
    longitude = Column(Numeric)
    population = Column(Integer)
    first_dose = Column(Integer)
    per_first_dose = Column (Integer)
    second_dose = Column(Integer)
    per_second_dose = Column(Integer)
    single_dose = Column(Integer)
    per_single_dose = Column(Integer)
    fully_vaccinated = Column(Integer)
    per_fully_vaccinated = Column(Integer)

class Gender(Base):
    __tablename__ = 'gender'

    male = Column(Integer)
    female = Column(Integer)
    undefined = Column(Integer)
    

class Race(Base):
    __tablename__ = 'race'

    race = Column(Text, primary_key=True)
    first_dose = Column(Integer)
    second_dose = Column(Integer)
    single_dose = Column(Integer)

def __str__(self):
    return self.county
    #return f"id={self.county, name={self.title}"